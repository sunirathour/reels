const response = require("../utills/response");
const dateFormat = require('date-and-time');
const fs = require("fs");
const path = require('path');
var http = require('http');
const csv = require('fast-csv');
const { parse } = require('csv-parse');
const converter = require('json-2-csv');



exports.dashboard = async (req, res) => {


    try {
      // let dirFiles =[];
      // const directoryPath = path.join(__dirname, '../data');
      // //passsing directoryPath and callback function
      // fs.readdir(directoryPath, function (err, files) {
      //     //handling error
      //     if (err) {
      //         //return console.log('Unable to scan directory: ' + err);
      //     } 
      //     //listing all files using forEach
     
      //     var stat = fs.lstatSync(directoryPath);
        
      //     files.forEach(function (file) {
      //         // Do whatever you want to do with the file
      //          dirFiles.push(file);
           
      //     });
        
      //     return res.render('dashboard', { url:req.url, dirFiles});
      // });

      const directoryPath = path.join(__dirname, '../data');
const dirents = fs.readdirSync(directoryPath, { withFileTypes: true });
const dirFiles = dirents
    .filter(dirent => dirent.isFile())
    .map(dirent => dirent.name).filter(f => f.includes(".csv"));
// use dirFiles

return res.render('dashboard', { url:req.url, dirFiles, dateFormat});
   
     
   
  } catch (err) {
      return res.send(err.message);
  } 

}


exports.getCsv = async (req, res) => {
    let filename = req.params.id;
       filename = filename+".csv";
    try {
    if(filename =="") return response.fail(res, "file name Required");
   // console.log({ responseString, fullUrl})
   const path = `./data/${filename}`;
   let fileExist= true;
   var csvData=[];
if (fs.existsSync(path)) {
    fileExist= true;
    fs.createReadStream(path)
    .pipe(parse({ delimiter: ",", from_line: 2 }))
    .on('data', function (row) {
       //console.log(row);
      let rr =  {
          'last_updated' : row[0], 
          'username':row[1],
          'user_id':row[2],
          'taken_at':row[3],
          'comment_count':row[4],
          'like_count':row[5],
          'url':row[6],
          'view_count':row[7],
          'play_count':row[8],
          'code':row[9],
          'link':row[10]
      };
       csvData.push(rr);
    })
    .on('end', function () {
     
      //console.log(csvData);
  
      return res.render('load_csv_file', { url:req.url, csvData, dateFormat, fileExist, filename});

    })
    .on('error', function (error) {
      console.log(error.message);
    
    });
} else {
    fileExist= false;
    //console.log('file not found!');
    return res.render('file_not_found', { url:req.url, csvData, dateFormat, fileExist, filename});
  }

} catch (err) {
    return response.fail(res, "Unable to get file");


}

}

exports.downloadCSV = async (req, res) => {

       const filename = req.body.file_name;
       console.log(filename);
      try {

          const directoryPath = path.join("data", filename );

          
          await res.download(directoryPath, filename);
         
          
          //return response.pass(res, "Data not available", flist);
      } catch (err) {
          return response.fail(res, "Unable to download file");
      }
  }

exports.shortcodes = async (req, res) => {


    try {

     
      return res.render('shortcodes', { url:req.url});
  } catch (err) {
      return res.send(err.message);
  } 

}




