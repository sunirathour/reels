const axios = require('axios');
const fs = require('fs');
const { parse } = require('csv-parse');
const converter = require('json-2-csv');
const response = require("../utills/response");

const API_KEY = 'b5441072ddmsh01314d3162b3154p1a67e1jsna4a4e6426925';

const retryDelay = 30;
const callDelay = 5;
const fetchOne = false;
let shortcodeIndex = 0;
let shortcodeCount = 0;
let shortcodes = [];
let shortcode;
let reelStatsArray = [];

const regex = /\/reel\/([^/\?]+)/;

exports.submitShortcodes = async (req, res) => {
  res = res;
  try {
      shortcodeIndex = 0;
      shortcodeCount = 0;
      shortcodes = [];
      shortcode;
      reelStatsArray = [];


    let shortcodes_row = req.body.shortcodes.trim();

    if(shortcodes_row =="" || shortcodes_row == undefined)   return response.fail(res, "Shortcodes Required");
     let shortcodes_data = shortcodes_row.split("\n");
     for(ss of shortcodes_data ){
      let matches = regex.exec(ss);
      //console.log({matches});
      if(matches == null) return response.fail(res, "Invalid Shortcodes");
      if (matches) {
        shortcodes.push(matches[1]);
      }
     }
   
    shortcodeCount = shortcodes.length;
    // console.log({ shortcodes, shortcodeCount: shortcodes.length})
    //return "defefef";
    //sunil-comment console.log(`-[ Processing ${shortcodes.length} shortcodes... ]-`);
    let data_status = await startPipeline(req, res);

    if(data_status){
    return response.pass(res, "Success");
    }
 

} catch (err) {
  return res.send(err.message);
} 

}
// convert JSON array to CSV string
const writeCSV = (jsonData, fname) => {
  converter.json2csv(jsonData, (err, csv) => {
    if (err) {
      throw err;
    }

    //sunil-comment console.log("write CSV to a file", fname);
    // write CSV to a file
    fs.writeFileSync(`data/${fname}`, csv);
  });
};

// GET REELS
const get_reel_stats = function (req, res, shortcode) {

  process.stdout.write(`Index: ${shortcodeIndex} > ${shortcode}...`);

  const options = {
    method: 'GET',
    url: 'https://instagram-scraper-2022.p.rapidapi.com/ig/reel/',
    params: { shortcode: shortcode },
    headers: {
      'X-RapidAPI-Key': API_KEY,
      'X-RapidAPI-Host': 'instagram-scraper-2022.p.rapidapi.com',
    },
  };

  axios
    .request(options)
    .then(function (response) {
      let reel = response.data;

      let tempObj = {};
      tempObj['last_updated'] = Date.now();
      tempObj['username'] = reel['owner']['username'];
      tempObj['user_id'] = reel['owner']['id'];
      tempObj['taken_at'] = reel['taken_at_timestamp'];
      tempObj['comment_count'] = reel['edge_media_to_comment']['count'];
      tempObj['like_count'] = reel['edge_media_preview_like']['count'];
      tempObj['url'] = reel['video_url'];
      tempObj['view_count'] = reel['video_view_count'];
      tempObj['play_count'] = reel['video_play_count'];
      tempObj['code'] = reel['shortcode'];
      tempObj[
        'link'
      ] = `https://www.instagram.com/reel/${tempObj['code']}/`;

      //sunil-comment console.log(tempObj);

      reelStatsArray.push(tempObj);

      if (fetchOne) {
       var f_name =  `reel_stats-${Date.now()}.csv`;
        // WRITE CSV
        writeCSV(reelStatsArray, f_name);
        return response.pass(res, "All Done");
        //sunil-comment console.log('-----> ALL DONE <-----');
      } else
        setTimeout(() => {
          // NEXT SHORTCODE
          shortcodeIndex += 1;

          startPipeline(req, res);
        }, callDelay * 1000);
    })
    .catch(function (error) {
       console.error(error);
      //return response.fail(res, `ERROR >>> Retrying after ${retryDelay} seconds...`);
      //sunil-comment console.error(`ERROR >>> Retrying after ${retryDelay} seconds...`);
      return response.fail(res, "retryDelay");
      // setTimeout(() => {
      //   startPipeline(req, res);
      // }, retryDelay * 1000);
    });
};


const startPipeline = (req, res) => {
  console.log({shortcodeIndex, shortcodeCount});
  if (shortcodeIndex < shortcodeCount) {
     
    get_reel_stats(req, res, shortcodes[shortcodeIndex]);
  } else {
    var f_name =  `reel_stats-${Date.now()}.csv`;
    // WRITE CSV
    writeCSV(reelStatsArray,f_name);
    //return response.fail(res, `Successfully Run`);
    //sunil-comment console.log('-----> ALL DONE <-----');
    return response.pass(res, "All Done ###"+f_name);
  }
};