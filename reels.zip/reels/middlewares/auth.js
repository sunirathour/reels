exports.authenticated = (req, res, next) =>{

    if(!req.session.isLoggedIn){
          return res.redirect('/login');
        }

        next();
}

exports.guest = (req, res, next) =>{

    if(req.session.isLoggedIn){
          return res.redirect('/dashboard');
        }

        next();
}