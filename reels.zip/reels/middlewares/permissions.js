const _ = require('underscore');
const response = require('../utills/response');


module.exports = async (req, res, next) => {
     //console.log(req.session.user );
    try{
    const permissions = req.session.user.permissions;
     
    const path = req.path;
        
    if (!_.contains(permissions, path)) {
        if (req.headers["x-requested-with"] == 'XMLHttpRequest') {
            return response.fail(res, "Permission Denied");
        }

        return res.redirect('/dashboard');

      
    }

        next();
    }
    catch (err) {
        
        return response.fail(res, err.message);
    }
   

}