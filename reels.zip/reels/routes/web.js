const express = require('express');
const route = express.Router();

const dashboardController = require('../controllers/dashboardController');
const getReelStatsLocal = require('../controllers/getReelStatsLocal');
// const loginController = require('../controllers/loginController');
const auth = require('../middlewares/auth');
// const validator = require('../utills/validator');




// route.get('/', auth.guest, loginController.showLoginForm);

// route.get("/login", auth.guest, loginController.showLoginForm);
// route.post("/login", auth.guest, validator.loginValidation, loginController.loginPost);
// route.get("/logout", loginController.logout);

//route.get('/', dashboardController.dashboard);
//route.get('/shortcodes', dashboardController.shortcodes);
route.get('/', dashboardController.shortcodes);
route.get('/:id', dashboardController.getCsv);
//route.post('/download-csv', dashboardController.downloadCSV);
route.post('/submit-shortcodes', getReelStatsLocal.submitShortcodes);



module.exports = route;
