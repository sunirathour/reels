const express = require('express');
const fs = require('fs');
const bodyParser = require('body-parser');
//const mongoose = require('mongoose');
const session = require('express-session');
//const MongoDBStore = require('connect-mongodb-session')(session);
const flash = require('connect-flash')
const csrf = require('csurf');
const multer = require('multer');
const path = require('path');
const app = express();
const Permission = require("./middlewares/permissions");

const server = require('http').createServer(app);
const io = require('socket.io')(server);

// const connectionString = "mongodb://localhost:27017/engine";


// const store = new MongoDBStore({
//     uri: connectionString,
//     collection: "sessions"
//   });
  
const csrfProtection = csrf();


app.set("view engine", "ejs");
app.set("views", "views");
app.use(flash());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(express.static(path.join(__dirname, "public")));
app.use(express.static(path.join(__dirname, "data")));

//app.use(session({ secret: "savendra", resave: false, saveUninitialized: false, store: store }));
//app.use(csrfProtection);
app.use((req, res, next) => {
  //res.locals.isAuthenticated = req.session.isLoggedIn;
  //res.locals.csrfToken = req.csrfToken();
  //res.locals.error = req.flash('error')[0];
  //res.locals.success = req.flash('success')[0];
  next();
})

const errorController = require('./controllers/errorController');
const web = require('./routes/web');
//const admin_routes = require('./routes/admin_routes');

app.use([web]);
// app.use([Permission]);
// app.use([admin_routes]);

app.get("/500", errorController.get500);
app.use(errorController.get404);

app.use((error, req, res, next) =>{
  console.log(error);
    res.status(500).render('errors/500');
});


// mongoose.connect(connectionString, { useNewUrlParser: true, useUnifiedTopology: true })
//   .then(() => {
    const port = process.env.PORT || 5500;
    server.listen(port, () => {
      console.log("Server listening on port " + port);
    })
  // })
  //.catch(err => console.log(err));