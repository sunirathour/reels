const {
    check,
    body
} = require('express-validator');
const User = require('../models/user');

exports.loginValidation = [
    //body('username').isEmail().withMessage("Please provide valid email"),
    body('username').not().isEmpty().withMessage("Username field cannot be blank").trim()
    .escape()
    .isLength({
        min: 2
    }).withMessage("Username required atleast 2 character"),
    body('password')
    .not()
    .isEmpty().withMessage("Password field cannot be blank")
    .trim()
    .escape()
    .isLength({
        min: 5
    })
    .withMessage("Password required atleast 5 character")
];